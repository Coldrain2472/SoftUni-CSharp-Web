﻿namespace CinemaApp.Common
{
    public static class ApplicationConstants
    {
        public const int ReleaseYear = 2024;
    }
}
