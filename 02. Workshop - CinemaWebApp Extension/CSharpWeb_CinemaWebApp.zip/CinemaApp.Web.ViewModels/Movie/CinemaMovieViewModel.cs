﻿namespace CinemaApp.Web.ViewModels.Movie
{
    public class CinemaMovieViewModel
    {
        public string Title { get; set; } = null!;

        public int Duration { get; set; }
    }
}
